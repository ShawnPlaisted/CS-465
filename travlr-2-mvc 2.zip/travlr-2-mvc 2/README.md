# Module Two -- MVC Refactor with HBS (Travlr)

This project refactors the Travlr application to follow the
Model--View--Controller (MVC) architecture using Express and Handlebars
(HBS). Static HTML pages were converted into dynamic templates, and the
project structure was reorganized to improve scalability and clarity.

## How to Run

1.  Install dependencies:

    ``` bash
    npm install
    ```

2.  Start the app:

    ``` bash
    npm start
    ```

3.  Open the site in your browser:

    -   Home: http://localhost:3000
    -   Travel: http://localhost:3000/travel

## Project Structure

    travlr-2-mvc/
    │
    ├── app.js
    ├── package.json
    ├── public/
    │   └── css/
    │       └── style.css
    │
    └── app_server/
        ├── controllers/
        │   └── travelerController.js
        ├── routes/
        │   ├── index.js
        │   └── travel.js
        └── views/
            ├── layouts/
            │   └── main.hbs
            ├── partials/
            │   ├── header.hbs
            │   ├── nav.hbs
            │   └── footer.hbs
            ├── index.hbs
            ├── travel.hbs
            └── 404.hbs

## Description

The application now uses a structured MVC approach. Routes define
endpoints, controllers handle logic and prepare data, and views render
Handlebars templates. Shared partials simplify the layout and keep the
UI consistent across pages.

## Routes and Controllers

-   `/` --- Loads the home page\
-   `/travel` --- Loads the travel page and displays trip data

Both routes connect to controller functions in travelerController.js.

## Templates

-   main.hbs --- Base layout for all pages\
-   header.hbs, nav.hbs, footer.hbs --- Shared partials\
-   travel.hbs --- Renders all trip details using {{#each}}, {{#if}},
    and other Handlebars helpers

## Testing

1.  Start the application with npm start.\
2.  Visit /travel and verify:
    -   Trip information loads correctly\
    -   Featured trips display a "Featured" badge\
    -   Tags appear for each trip\
    -   Navigation works throughout the site

## Notes

-   Sample data is stored in the controller.\
-   The MVC structure allows easy future expansion, including adding a
    database.
