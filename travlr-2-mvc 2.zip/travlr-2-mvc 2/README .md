# Module Two – MVC Refactor with HBS (Travlr)

This project refactors the Travlr website to follow the Model-View-Controller (MVC) architecture using Express and Handlebars (HBS). It converts static HTML pages into dynamic templates and organizes the code for scalability and clarity.

## How to Run

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the app:
   ```bash
   npm start
   ```

3. Open the site in your browser:
   - Home: [http://localhost:3000](http://localhost:3000)
   - Travel: [http://localhost:3000/travel](http://localhost:3000/travel)

## Project Structure

```
travlr-2-mvc/
│
├── app.js
├── package.json
├── public/
│   └── css/
│       └── style.css
│
└── app_server/
    ├── controllers/
    │   └── travelerController.js
    ├── routes/
    │   ├── index.js
    │   └── travel.js
    └── views/
        ├── layouts/
        │   └── main.hbs
        ├── partials/
        │   ├── header.hbs
        │   ├── nav.hbs
        │   └── footer.hbs
        ├── index.hbs
        ├── travel.hbs
        └── 404.hbs
```

## Description

The Travlr site has been updated to use a structured MVC approach. Controllers handle logic, routes manage endpoints, and views render templates. The application uses Handlebars for dynamic content and reusable partials.

## Routes and Controllers

- `/` – Renders the home page  
- `/travel` – Renders the travel page with trip data  

Both routes are connected to controller functions in `travelerController.js`.

## Templates

- `main.hbs` – Shared layout for all pages  
- `header.hbs`, `nav.hbs`, `footer.hbs` – Reusable partials  
- `travel.hbs` – Uses Handlebars helpers such as `{{#each}}` and `{{#if}}` to render data dynamically

## Testing

1. Start the app using `npm start`.  
2. Visit `/travel` in a browser and confirm that:
   - Trip information is displayed.  
   - Featured trips show a “Featured” label.  
   - Tags appear for each trip.  
   - Navigation works between pages.  

## Notes

- The data in the controller is sample content.  
- The project can be expanded to include database connections in future milestones.
