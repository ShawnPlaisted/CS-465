// app_server/routes/index.js
const express = require('express');
const router = express.Router();

// Controllers
const travelerCtrl = require('../controllers/travelerController');
const tripsController = require('../controllers/trips');

// Home page
router.get('/', travelerCtrl.getHome);

// Trips page (we support both /travel and /trips)
router.get('/travel', tripsController.tripsList);
router.get('/trips', tripsController.tripsList);

module.exports = router;