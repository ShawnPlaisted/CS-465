// app_server/routes/index.js
const express = require('express');
const router = express.Router();
const travelerCtrl = require('../controllers/travelerController');

router.get('/', travelerCtrl.getHome);

module.exports = router;
