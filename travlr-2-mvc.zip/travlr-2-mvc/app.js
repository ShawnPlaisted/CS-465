const path = require('path');
const express = require('express');
const morgan = require('morgan');
const hbs = require('hbs');

const indexRouter = require('./app_server/routes/index');
const travelRouter = require('./app_server/routes/travel');

const app = express();

app.use(morgan('dev'));

// View engine
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register partials
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Static assets
app.use(express.static(path.join(__dirname, 'public')));

// Expose a global year helper via locals
app.use((req, res, next) => {
  res.locals.year = new Date().getFullYear();
  next();
});

// Routes
app.use('/', indexRouter);
app.use('/travel', travelRouter);

// 404
app.use((req, res) => {
  res.status(404);
  res.render('404', { title: 'Not Found', url: req.originalUrl, layout: 'layouts/main' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
