const path = require('path');
const express = require('express');
const morgan = require('morgan');
const hbs = require('hbs');
const cookieParser = require('cookie-parser');

// MVC routes
const indexRouter = require('./app_server/routes/index');
const travelRouter = require('./app_server/routes/travel');

// API routes
require('./app_api/models/db');
const apiRouter = require('./app_api/routes/index');

const app = express();

// Logging
app.use(morgan('dev'));

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// View engine
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// MVC routes
app.use('/', indexRouter);
app.use('/travel', travelRouter);

// API routes
app.use('/api', apiRouter);

// 404 handler
app.use((req, res) => {
  res.status(404);
  res.render('404', {
    title: 'Not Found',
    url: req.originalUrl,
    layout: 'layouts/main'
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));

module.exports = app;
