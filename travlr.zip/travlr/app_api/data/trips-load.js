// Script to load trips.json data into MongoDB using Mongoose

const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

// Initialize Mongoose connection and models
require('../models/db');
require('../models/trips');

const Trip = mongoose.model('Trip');

const dataPath = path.join(__dirname, '..', '..', 'data', 'trips.json');

const trips = JSON.parse(fs.readFileSync(dataPath, 'utf8'));

const loadTrips = async () => {
  try {
    console.log('Clearing existing trips collection...');
    await Trip.deleteMany({});

    console.log('Inserting seed trips data...');
    await Trip.insertMany(trips);

    console.log('Trips data successfully loaded.');
  } catch (err) {
    console.error('Error loading trips data:', err);
  } finally {
    mongoose.connection.close(() => {
      console.log('Mongoose connection closed.');
      process.exit(0);
    });
  }
};

loadTrips();
