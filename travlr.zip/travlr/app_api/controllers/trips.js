const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().exec();
    return res.status(200).json(trips);
  } catch (err) {
    console.error('Error fetching trips:', err);
    return res.status(500).json({
      message: 'Error fetching trips',
      error: err
    });
  }
};

const tripsFindByCode = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!tripCode) {
    return res.status(400).json({ message: 'tripCode parameter is required' });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode }).exec();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error('Error fetching trip by code:', err);
    return res.status(500).json({
      message: 'Error fetching trip by code',
      error: err
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode
};
